const crypto = require('crypto');
const { readData, writeData, bumpStreak, normalizeEmail, cafeteriaPayload } = require('./_lib/db');
const { ensureSeeded } = require('./_lib/seed');
const { withErrors } = require('./_lib/wrap');

module.exports = withErrors(async function handler(req, res) {
  await ensureSeeded();

  if (req.method === 'POST') {
    const { room, message, email, id } = req.body || {};
    if (!message || !String(message).trim()) return res.status(400).json({ error: 'Message is required' });
    if (!email || !String(email).trim()) return res.status(400).json({ error: 'Email is required' });

    const data = await readData();
    const isCafeteria = !room || room === 'cafeteria';
    const key = isCafeteria ? null : String(room).trim().toLowerCase();
    if (!isCafeteria && !data.rooms[key]) return res.status(404).json({ error: 'Room not found' });

    const list = isCafeteria ? data.cafeteria.comments : (data.rooms[key].reports || []);

    if (id) {
      const existing = list.find((r) => r.id === id);
      if (!existing) return res.status(404).json({ error: 'Comment not found' });
      if (existing.email !== normalizeEmail(email)) return res.status(403).json({ error: 'You can only edit your own comments' });
      existing.message = String(message).trim().slice(0, 300);
      existing.editedAt = Date.now();
    } else {
      const entry = {
        id: crypto.randomUUID(),
        message: String(message).trim().slice(0, 300),
        email: normalizeEmail(email),
        timestamp: Date.now(),
      };
      if (isCafeteria) {
        data.cafeteria.comments.unshift(entry);
        data.cafeteria.comments = data.cafeteria.comments.slice(0, 30);
      } else {
        if (!data.rooms[key].reports) data.rooms[key].reports = [];
        data.rooms[key].reports.unshift(entry);
        data.rooms[key].reports = data.rooms[key].reports.slice(0, 20);
      }
    }

    bumpStreak(data, email);
    await writeData(data);

    const user = data.users[normalizeEmail(email)] || { streak: 0 };
    return res.status(200).json({
      rooms: Object.values(data.rooms).sort((a, b) => b.timestamp - a.timestamp),
      cafeteria: cafeteriaPayload(data),
      streak: user.streak,
    });
  }

  if (req.method === 'DELETE') {
    const { room, id, email } = req.body || {};
    if (!id) return res.status(400).json({ error: 'Comment id is required' });
    if (!email || !String(email).trim()) return res.status(400).json({ error: 'Email is required' });

    const data = await readData();
    const isCafeteria = !room || room === 'cafeteria';
    const key = isCafeteria ? null : String(room).trim().toLowerCase();
    if (!isCafeteria && !data.rooms[key]) return res.status(404).json({ error: 'Room not found' });

    const list = isCafeteria ? data.cafeteria.comments : (data.rooms[key].reports || []);
    const index = list.findIndex((r) => r.id === id);
    if (index === -1) return res.status(404).json({ error: 'Comment not found' });
    if (list[index].email !== normalizeEmail(email)) return res.status(403).json({ error: 'You can only delete your own comments' });
    list.splice(index, 1);

    await writeData(data);
    return res.status(200).json({
      rooms: Object.values(data.rooms).sort((a, b) => b.timestamp - a.timestamp),
      cafeteria: cafeteriaPayload(data),
    });
  }

  res.setHeader('Allow', 'POST, DELETE');
  return res.status(405).json({ error: 'Method not allowed' });
});
