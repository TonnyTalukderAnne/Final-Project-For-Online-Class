const { readData, writeData, normalizeEmail } = require('./_lib/db');
const { ensureSeeded } = require('./_lib/seed');
const { withErrors } = require('./_lib/wrap');

module.exports = withErrors(async function handler(req, res) {
  await ensureSeeded();

  if (req.method === 'GET') {
    const email = normalizeEmail(req.query.email);
    const data = await readData();
    const user = data.users[email] || { favorites: [], streak: 0 };
    return res.status(200).json({
      favorites: user.favorites || [],
      streak: user.streak || 0,
      myRating: data.cafeteria.ratings[email] || 0,
    });
  }

  if (req.method === 'POST') {
    const email = normalizeEmail((req.body || {}).email);
    const room = String((req.body || {}).room || '').trim().toLowerCase();
    const action = (req.body || {}).action === 'remove' ? 'remove' : 'add';
    if (!email || !room) return res.status(400).json({ error: 'Email and room are required' });

    const data = await readData();
    if (!data.users[email]) data.users[email] = { favorites: [], streak: 0, lastReportDate: null };
    const favs = new Set(data.users[email].favorites || []);
    if (action === 'add') favs.add(room);
    else favs.delete(room);
    data.users[email].favorites = Array.from(favs);
    await writeData(data);
    return res.status(200).json({ favorites: data.users[email].favorites });
  }

  res.setHeader('Allow', 'GET, POST');
  return res.status(405).json({ error: 'Method not allowed' });
});
