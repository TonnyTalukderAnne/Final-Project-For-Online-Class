const { readData, cafeteriaPayload } = require('./_lib/db');
const { ensureSeeded } = require('./_lib/seed');
const { withErrors } = require('./_lib/wrap');

module.exports = withErrors(async function handler(req, res) {
  await ensureSeeded();

  if (req.method !== 'GET') {
    res.setHeader('Allow', 'GET');
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const data = await readData();
  return res.status(200).json(cafeteriaPayload(data));
});
