const { readData, writeData, bumpStreak, cafeteriaPayload } = require('../_lib/db');
const { ensureSeeded } = require('../_lib/seed');
const { withErrors } = require('../_lib/wrap');

module.exports = withErrors(async function handler(req, res) {
  await ensureSeeded();

  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { level, email } = req.body || {};
  if (!['short', 'medium', 'long'].includes(level)) return res.status(400).json({ error: 'Queue level must be short, medium, or long' });
  if (!email || !String(email).trim()) return res.status(400).json({ error: 'Email is required' });

  const data = await readData();
  data.cafeteria.queue = { level, timestamp: Date.now(), updatedBy: email };
  bumpStreak(data, email);
  await writeData(data);
  return res.status(200).json(cafeteriaPayload(data));
});
