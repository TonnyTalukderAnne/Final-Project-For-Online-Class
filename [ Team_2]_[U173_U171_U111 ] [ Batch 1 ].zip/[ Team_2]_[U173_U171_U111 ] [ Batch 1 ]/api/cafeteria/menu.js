const { readData, writeData, bumpStreak, normalizeEmail, cafeteriaPayload, WEEK_DAYS } = require('../_lib/db');
const { ensureSeeded } = require('../_lib/seed');
const { withErrors } = require('../_lib/wrap');

module.exports = withErrors(async function handler(req, res) {
  await ensureSeeded();

  if (req.method === 'POST') {
    const { day, menu, email } = req.body || {};
    if (!WEEK_DAYS.includes(day)) return res.status(400).json({ error: 'Invalid day' });
    if (typeof menu !== 'string') return res.status(400).json({ error: 'Menu text is required' });
    if (!email || !String(email).trim()) return res.status(400).json({ error: 'Email is required' });

    const data = await readData();
    data.cafeteria.weeklyMenu[day] = {
      text: menu.trim().slice(0, 500),
      updatedAt: Date.now(),
      updatedBy: normalizeEmail(email),
    };
    bumpStreak(data, email);
    await writeData(data);
    return res.status(200).json(cafeteriaPayload(data));
  }

  if (req.method === 'DELETE') {
    const { day } = req.body || {};
    if (!WEEK_DAYS.includes(day)) return res.status(400).json({ error: 'Invalid day' });
    const data = await readData();
    delete data.cafeteria.weeklyMenu[day];
    await writeData(data);
    return res.status(200).json(cafeteriaPayload(data));
  }

  res.setHeader('Allow', 'POST, DELETE');
  return res.status(405).json({ error: 'Method not allowed' });
});
