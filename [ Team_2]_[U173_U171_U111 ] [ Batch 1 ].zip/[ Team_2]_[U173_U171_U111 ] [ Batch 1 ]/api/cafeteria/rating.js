const { readData, writeData, bumpStreak, normalizeEmail, cafeteriaPayload } = require('../_lib/db');
const { ensureSeeded } = require('../_lib/seed');
const { withErrors } = require('../_lib/wrap');

module.exports = withErrors(async function handler(req, res) {
  await ensureSeeded();

  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { stars, email } = req.body || {};
  const n = Number(stars);
  if (!Number.isInteger(n) || n < 1 || n > 5) return res.status(400).json({ error: 'Rating must be 1-5' });
  if (!email || !String(email).trim()) return res.status(400).json({ error: 'Email is required' });

  const data = await readData();
  data.cafeteria.ratings[normalizeEmail(email)] = n;
  bumpStreak(data, email);
  await writeData(data);
  return res.status(200).json(cafeteriaPayload(data));
});
