/**
 * Wraps a Vercel serverless function handler so any thrown error
 * (e.g. "no storage connected") becomes a readable JSON error response
 * instead of a bare 500 with no detail — the frontend's toast then
 * shows it directly, no need to dig through Vercel's function logs.
 */

function withErrors(fn) {
  return async function handler(req, res) {
    try {
      await fn(req, res);
    } catch (err) {
      if (!res.headersSent) {
        res.status(500).json({ error: (err && err.message) || 'Internal server error' });
      }
    }
  };
}

module.exports = { withErrors };
