/**
 * Shared data-access helpers for Vercel serverless functions.
 * Mirrors the logic in server.js (used for local/Render deployments),
 * but reads/writes a single JSON blob in a Redis-compatible store
 * instead of a file (serverless functions have no persistent disk).
 *
 * Auto-detects whichever storage integration got connected in the
 * Vercel dashboard, trying these patterns in order:
 *  1. Vercel KV               → KV_REST_API_URL + KV_REST_API_TOKEN            (@vercel/kv)
 *  2. Upstash Redis (REST)    → UPSTASH_REDIS_REST_URL + UPSTASH_REDIS_REST_TOKEN (@upstash/redis)
 *  3. Any standard redis:// connection string in any env var          (redis)
 * If none of these are found, the error thrown lists every env var
 * name (not value) that looks storage-related, so whatever actually
 * got created in the dashboard is visible immediately for debugging.
 */

const crypto = require('crypto');

const DB_KEY = 'campusnow:data';

const DEFAULT_DATA = {
  rooms: {},
  cafeteria: { weeklyMenu: {}, queue: null, comments: [], ratings: {} },
  users: {},
};

let store = null; // { get(key), set(key, value) } once resolved

function findEnv(names) {
  for (const name of names) {
    if (process.env[name]) return process.env[name];
  }
  return null;
}

function findRedisUrl() {
  for (const value of Object.values(process.env)) {
    if (typeof value === 'string' && (value.startsWith('redis://') || value.startsWith('rediss://'))) {
      return value;
    }
  }
  return null;
}

function relatedEnvVarNames() {
  return Object.keys(process.env).filter((k) => /REDIS|KV_|UPSTASH/i.test(k));
}

async function getStore() {
  if (store) return store;

  // 1. Vercel KV
  const kvUrl = findEnv(['KV_REST_API_URL']);
  const kvToken = findEnv(['KV_REST_API_TOKEN']);
  if (kvUrl && kvToken) {
    const { kv } = require('@vercel/kv');
    store = { get: (k) => kv.get(k), set: (k, v) => kv.set(k, v) };
    return store;
  }

  // 2. Upstash Redis via its REST API (common name when connected through
  //    the Vercel Marketplace rather than native Vercel KV)
  const upstashUrl = findEnv(['UPSTASH_REDIS_REST_URL', 'KV_REST_API_URL']);
  const upstashToken = findEnv(['UPSTASH_REDIS_REST_TOKEN', 'KV_REST_API_TOKEN']);
  if (upstashUrl && upstashToken) {
    const { Redis } = require('@upstash/redis');
    const client = new Redis({ url: upstashUrl, token: upstashToken });
    store = { get: (k) => client.get(k), set: (k, v) => client.set(k, v) };
    return store;
  }

  // 3. Any standard TCP redis:// / rediss:// connection string
  const redisUrl = findEnv(['REDIS_URL', 'KV_URL']) || findRedisUrl();
  if (redisUrl) {
    const { createClient } = require('redis');
    const client = createClient({ url: redisUrl });
    client.on('error', () => {});
    await client.connect();
    store = {
      get: async (k) => {
        const raw = await client.get(k);
        return raw ? JSON.parse(raw) : null;
      },
      set: (k, v) => client.set(k, JSON.stringify(v)),
    };
    return store;
  }

  const found = relatedEnvVarNames();
  throw new Error(
    found.length
      ? `Storage env vars found but not recognized: ${found.join(', ')}. Update api/_lib/db.js to read these names.`
      : 'No storage connected at all. In the Vercel dashboard, open this project → Storage → Create Database → connect it to this project → redeploy.'
  );
}

async function storeGet(key) {
  const s = await getStore();
  return s.get(key);
}

async function storeSet(key, value) {
  const s = await getStore();
  return s.set(key, value);
}

async function readData() {
  const data = await storeGet(DB_KEY);
  if (!data) return JSON.parse(JSON.stringify(DEFAULT_DATA));
  if (!data.rooms) data.rooms = {};
  if (!data.cafeteria) data.cafeteria = { weeklyMenu: {}, queue: null, comments: [], ratings: {} };
  if (!data.cafeteria.weeklyMenu) data.cafeteria.weeklyMenu = {};
  if (!data.cafeteria.comments) data.cafeteria.comments = [];
  if (!data.cafeteria.ratings) data.cafeteria.ratings = {};
  if (!data.users) data.users = {};

  // Backfill: comments/reports created before edit/delete existed have no
  // `id`, so editing/deleting them silently failed (couldn't be matched).
  // Give any of those a fresh id and persist it so it becomes editable.
  let backfilled = false;
  data.cafeteria.comments.forEach((c) => {
    if (!c.id) { c.id = crypto.randomUUID(); backfilled = true; }
  });
  Object.values(data.rooms).forEach((room) => {
    (room.reports || []).forEach((r) => {
      if (!r.id) { r.id = crypto.randomUUID(); backfilled = true; }
    });
  });
  if (backfilled) await writeData(data);

  return data;
}

async function writeData(data) {
  await storeSet(DB_KEY, data);
}

function normalizeEmail(email) {
  return String(email || '').trim().toLowerCase();
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function bumpStreak(data, email) {
  const key = normalizeEmail(email);
  if (!key) return;
  if (!data.users[key]) data.users[key] = { favorites: [], streak: 0, lastReportDate: null };
  const u = data.users[key];
  const today = todayStr();
  if (u.lastReportDate !== today) {
    const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
    u.streak = u.lastReportDate === yesterday ? u.streak + 1 : 1;
    u.lastReportDate = today;
  }
}

function ratingSummary(ratings) {
  const values = Object.values(ratings || {});
  if (values.length === 0) return { average: 0, count: 0 };
  const sum = values.reduce((a, b) => a + b, 0);
  return { average: Math.round((sum / values.length) * 10) / 10, count: values.length };
}

function cafeteriaPayload(data) {
  return {
    weeklyMenu: data.cafeteria.weeklyMenu,
    queue: data.cafeteria.queue,
    comments: data.cafeteria.comments,
    rating: ratingSummary(data.cafeteria.ratings),
  };
}

const WEEK_DAYS = ['Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

module.exports = {
  storeGet,
  storeSet,
  readData,
  writeData,
  normalizeEmail,
  todayStr,
  bumpStreak,
  ratingSummary,
  cafeteriaPayload,
  WEEK_DAYS,
};
