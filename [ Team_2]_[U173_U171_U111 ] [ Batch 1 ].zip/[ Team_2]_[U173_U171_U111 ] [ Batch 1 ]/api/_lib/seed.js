/**
 * One-time seed for Vercel KV storage — same 24 demo rooms and 7-day
 * menu that ship in data.json for local/Render runs. Runs once per KV
 * database (guarded by a "seeded" flag key), so it never overwrites
 * real data added later.
 */

const { storeGet, storeSet, writeData } = require('./db');

const SEEDED_FLAG_KEY = 'campusnow:seeded';
const HOUR = 60 * 60 * 1000;

const roomDefs = [
  ['Library 2F Corner', 'study', 'free', 'Quiet corner, good for solo focus', 0.3],
  ['Library 3F Group Zone', 'study', 'occupied', 'Group project in progress', 1.1],
  ['CSE Building Room 301', 'study', 'free', 'Whiteboard available', 0.6],
  ['CSE Building Room 305', 'study', 'occupied', 'Class in session', 0.2],
  ['CSE Building Room 402', 'study', 'free', '', 2.5],
  ['EEE Building Room 210', 'study', 'occupied', 'Lab session running', 0.4],
  ['EEE Building Room 214', 'study', 'free', 'Power outlets on every desk', 1.8],
  ['Business Faculty Room 108', 'study', 'free', 'Good for presentations practice', 0.9],
  ['Business Faculty Room 112', 'study', 'occupied', '', 3.2],
  ['Central Library Silent Zone', 'study', 'free', 'No talking allowed, great for exams prep', 0.1],
  ['Central Library Discussion Room 1', 'study', 'occupied', 'Booked for thesis defense practice', 1.4],
  ['Central Library Discussion Room 2', 'study', 'free', 'Glass room, holds 6 people', 0.7],
  ['Math Building Room 15', 'study', 'free', '', 4.1],
  ['Architecture Studio A', 'study', 'occupied', 'Model-making in progress', 0.5],
  ['Architecture Studio B', 'study', 'free', 'Large tables, good for model work', 1.0],
  ['Student Lounge — Block A', 'rest', 'free', 'Couches, good for napping', 0.2],
  ['Student Lounge — Block B', 'rest', 'occupied', 'Crowded during lunch hour', 0.3],
  ['Rooftop Garden Deck', 'rest', 'free', 'Fresh air, hammock chairs', 1.6],
  ['Cafeteria Annex Seating', 'rest', 'occupied', '', 0.8],
  ['TSC Common Room', 'rest', 'free', 'TV + couches', 2.0],
  ['Gymnasium Lobby Benches', 'rest', 'free', 'Quiet after morning classes', 3.0],
  ['Prayer Hall Rest Corner', 'rest', 'occupied', '', 1.2],
  ['Hostel Common Room', 'rest', 'free', 'Board games available', 0.4],
  ['Amphitheatre Shade Benches', 'rest', 'free', 'Best in the afternoon', 5.5],
];

const menuText = {
  Saturday: 'Rice, Beef bhuna, Dal, Mixed vegetables, Salad',
  Sunday: 'Rice, Chicken curry, Dal, Aloo bhaji, Salad',
  Monday: 'Khichuri, Egg curry, Beef curry, Papad',
  Tuesday: 'Rice, Fish curry (Rui), Dal, Shak bhaji',
  Wednesday: 'Biryani (Chicken), Borhani, Salad',
  Thursday: 'Rice, Mutton curry, Dal, Mixed vegetables',
  Friday: 'Polao, Roast chicken, Dal, Salad, Firni',
};

async function ensureSeeded() {
  const seeded = await storeGet(SEEDED_FLAG_KEY);
  if (seeded) return;

  const now = Date.now();

  const rooms = {};
  roomDefs.forEach(([name, purpose, status, note, hoursAgo]) => {
    const key = name.toLowerCase();
    rooms[key] = {
      name,
      purpose,
      status,
      note,
      timestamp: now - Math.round(hoursAgo * HOUR),
      updatedBy: 'demo@campusnow.app',
      reports: [],
    };
  });

  const weeklyMenu = {};
  Object.entries(menuText).forEach(([day, text]) => {
    weeklyMenu[day] = { text, updatedAt: now - 6 * HOUR, updatedBy: 'demo@campusnow.app' };
  });

  const data = {
    rooms,
    cafeteria: {
      weeklyMenu,
      queue: { level: 'medium', timestamp: now - 0.4 * HOUR, updatedBy: 'demo@campusnow.app' },
      comments: [
        { message: 'Biryani on Wednesday is always worth the wait!', email: 'demo@campusnow.app', timestamp: now - 5 * HOUR },
      ],
      ratings: { 'demo@campusnow.app': 4 },
    },
    users: {
      'demo@campusnow.app': { favorites: ['library 2f corner'], streak: 1, lastReportDate: new Date(now).toISOString().slice(0, 10) },
    },
  };

  await writeData(data);
  await storeSet(SEEDED_FLAG_KEY, true);
}

module.exports = { ensureSeeded };
