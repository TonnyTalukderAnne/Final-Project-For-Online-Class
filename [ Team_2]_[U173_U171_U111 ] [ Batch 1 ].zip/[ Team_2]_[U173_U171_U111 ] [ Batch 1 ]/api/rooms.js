const { readData, writeData, bumpStreak, normalizeEmail } = require('./_lib/db');
const { ensureSeeded } = require('./_lib/seed');
const { withErrors } = require('./_lib/wrap');

module.exports = withErrors(async function handler(req, res) {
  await ensureSeeded();

  if (req.method === 'GET') {
    const data = await readData();
    const rooms = Object.values(data.rooms).sort((a, b) => b.timestamp - a.timestamp);
    return res.status(200).json({ rooms });
  }

  if (req.method === 'POST') {
    const { name, purpose, status, note, email } = req.body || {};
    if (!name || !String(name).trim()) return res.status(400).json({ error: 'Room name is required' });
    if (!['study', 'rest'].includes(purpose)) return res.status(400).json({ error: 'Purpose must be "study" or "rest"' });
    if (!['free', 'occupied'].includes(status)) return res.status(400).json({ error: 'Status must be "free" or "occupied"' });
    if (!email || !String(email).trim()) return res.status(400).json({ error: 'Email is required' });

    const data = await readData();
    const key = String(name).trim().toLowerCase();
    const existing = data.rooms[key];
    data.rooms[key] = {
      name: String(name).trim(),
      purpose,
      status,
      note: note ? String(note).trim().slice(0, 200) : '',
      timestamp: Date.now(),
      updatedBy: normalizeEmail(email),
      reports: existing ? existing.reports || [] : [],
    };
    bumpStreak(data, email);
    await writeData(data);
    const rooms = Object.values(data.rooms).sort((a, b) => b.timestamp - a.timestamp);
    const user = data.users[normalizeEmail(email)] || { streak: 0 };
    return res.status(200).json({ rooms, streak: user.streak });
  }

  if (req.method === 'DELETE') {
    const { name } = req.body || {};
    if (!name || !String(name).trim()) return res.status(400).json({ error: 'Room name is required' });
    const data = await readData();
    const key = String(name).trim().toLowerCase();
    if (!data.rooms[key]) return res.status(404).json({ error: 'Room not found' });
    delete data.rooms[key];
    await writeData(data);
    const rooms = Object.values(data.rooms).sort((a, b) => b.timestamp - a.timestamp);
    return res.status(200).json({ rooms });
  }

  res.setHeader('Allow', 'GET, POST, DELETE');
  return res.status(405).json({ error: 'Method not allowed' });
});
