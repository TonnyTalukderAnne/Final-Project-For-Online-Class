const { readData, writeData, bumpStreak, normalizeEmail, cafeteriaPayload } = require('./_lib/db');
const { ensureSeeded } = require('./_lib/seed');
const { withErrors } = require('./_lib/wrap');

module.exports = withErrors(async function handler(req, res) {
  await ensureSeeded();

  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { room, message, email } = req.body || {};
  if (!message || !String(message).trim()) return res.status(400).json({ error: 'Message is required' });
  if (!email || !String(email).trim()) return res.status(400).json({ error: 'Email is required' });

  const data = await readData();
  const entry = {
    message: String(message).trim().slice(0, 300),
    email: normalizeEmail(email),
    timestamp: Date.now(),
  };

  if (!room || room === 'cafeteria') {
    data.cafeteria.comments.unshift(entry);
    data.cafeteria.comments = data.cafeteria.comments.slice(0, 30);
  } else {
    const key = String(room).trim().toLowerCase();
    if (!data.rooms[key]) return res.status(404).json({ error: 'Room not found' });
    if (!data.rooms[key].reports) data.rooms[key].reports = [];
    data.rooms[key].reports.unshift(entry);
    data.rooms[key].reports = data.rooms[key].reports.slice(0, 20);
  }

  bumpStreak(data, email);
  await writeData(data);

  const user = data.users[normalizeEmail(email)] || { streak: 0 };
  return res.status(200).json({
    rooms: Object.values(data.rooms).sort((a, b) => b.timestamp - a.timestamp),
    cafeteria: cafeteriaPayload(data),
    streak: user.streak,
  });
});
